# Challenge V1 starter kits

Datasets tagged to this challenge.

- neighborhoods: Boston neighborhood estimates, 2025
- ej: MassGIS environmental justice block groups
- permits: Boston approved building permits
- violations: Boston building and property violations
- scorecard: College Scorecard, Massachusetts
- onet: O*NET occupations
