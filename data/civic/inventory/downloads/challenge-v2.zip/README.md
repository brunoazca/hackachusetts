# Challenge V2 starter kits

Datasets tagged to this challenge.

- boston-311: Boston 311 service requests
- ej: MassGIS environmental justice block groups
- fema: OpenFEMA disaster declarations, Massachusetts
- ipeds: IPEDS institutional directory, Massachusetts
- openalex-works: OpenAlex works at the nine campuses, 2024
