# Challenge V5 starter kits

Datasets tagged to this challenge.

- scorecard: College Scorecard, Massachusetts
- ipeds: IPEDS institutional directory, Massachusetts
- onet: O*NET occupations
