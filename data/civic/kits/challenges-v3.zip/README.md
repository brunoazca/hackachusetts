# Challenge V3 starter kits

Datasets tagged to this challenge.

- mbta-alerts: MBTA service alerts
- mbta-routes: MBTA subway routes
- mbta-stations: MBTA rapid transit stations
- colleges: MassGIS colleges and universities
- bluebikes: Bluebikes station-to-station counts, November 2024
- vision-zero: Boston Vision Zero crash records
- cambridge-crashes: Cambridge police crash records
- cambridge-bikes: Cambridge citywide bicycle counts
- eco-totem: Cambridge Broadway bicycle counter
- fresh-pond: Cambridge Fresh Pond usership
- somerville-counts: Somerville bicycle and pedestrian counts
- numina: Boston Numina street sensors
