# Challenge V4 starter kits

Datasets tagged to this challenge.

- ipeds: IPEDS institutional directory, Massachusetts
- openalex-works: OpenAlex works at the nine campuses, 2024
